function out = Lorentz_dot(a,b,M)
    
    
    out = a'*M*b;

end