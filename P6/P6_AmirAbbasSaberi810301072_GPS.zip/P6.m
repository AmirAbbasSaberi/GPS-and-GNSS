clc
clear
close all
format long g
% git remote add origin git@github.com:Arsenic2000/GPS_matlab_master.git
% git branch -M main
% git push -u origin main
%%
path = 'mizu0770.15o';
[pos,sat] = mizuRinexExtraction(path);

clear P1 P2 L1 L2 L5 n p  k i hour minute sec month line s S1 S2 S5 year t C1 C2 C5 number number1 number2 sat_num day end_of_header
close all
c= 299792458;
we = 7.29211514671*10^-5;
iP1 = find(strcmpi(sat(1,:) , 'P1'));
gnss_name = char(sat(:,1));
index = find(strcmpi(gnss_name(:,1),"G") );
sat_gps = sat(index,:);
gps_name = char(sat_gps(:,1));
sat_gps = [str2double(string(gps_name(:,2:3))) cell2mat(sat_gps(:,2:end))];
t_rcv = sat_gps(:,end);
P = sat_gps(:,iP1);
t_emission = t_rcv - P/c;
filename = 'brdc0770.15n';
sat_gps(:,end+1) = t_emission;
[data] = Extract_Navigation_data (filename);

sat_gps = gps_time_delay_coordiante(data,sat_gps,pos,c,we);


sat_gps (:,28) = sat_gps (:,24)+sat_gps (:,25);

i = find(sat_gps(:,1) == 5);
deltaT_sat = sat_gps(i,end-2);
time = sat_gps(i,5)*3600 + sat_gps(i,6)*60 + sat_gps(i,7);


%% Bancroft

clear aj B 
n = 6;
B = [sat_gps(1:n,21:23),sat_gps(1:n,14)+sat_gps(1:n,26)];



M = eye(4);
M(4,4) = -1;
for i = 1:n
    b = B(i,:);
   aj(i,1) = 0.5*b*M*b'; 
    
end


syms x 

eq1 = Lorentz_dot((B'*B)^-1*B'*ones(n,1),(B'*B)^-1*B'*ones(n,1),M)*x^2 ...
    +2*(Lorentz_dot((B'*B)^-1*B'*ones(n,1),(B'*B)^-1*B'*aj,M)-1)*x ...
    +Lorentz_dot((B'*B)^-1*B'*aj,(B'*B)^-1*B'*aj,M) == 0;

lambda = solve(eq1);
lambda = max(double(lambda));


r_cdt = M*(B'*B)^-1*B'*(lambda*ones(n,1)+aj);
ground_pos0 = r_cdt(1:3);

diff_pos = ground_pos0 - pos


sat_gps(:,end+1) = sqrt(sum(sat_gps(:,21:23).^2,2));


